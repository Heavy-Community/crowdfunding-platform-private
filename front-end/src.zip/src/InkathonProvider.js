import { ApiPromise, WsProvider } from '@polkadot/api';
import { InkathonProvider, createApi } from '@scio-labs/use-inkathon';
import { useEffect } from 'react';

const wsProvider = new WsProvider('wss://rococo-contracts-rpc.polkadot.io');
const api = createApi({ provider: wsProvider });

const InkathonProviderWrapper = ({ children }) => {
  return (
    <InkathonProvider api={api}>
      {children}
    </InkathonProvider>
  );
};

export default InkathonProviderWrapper;
