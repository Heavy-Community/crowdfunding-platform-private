// Address of our deployed ERC20 token on Rococo-Contracts testnet
export const address = '5Hgiu38EojYy9DLpJJcNXer18ubxGh8bZLZv86SBf2kEmXeu'
